<html>
<head>
<link rel="stylesheet" media="screen" type="text/css" href="../styl.css"/>
</head>
<body class='register-body'>
<div  class="dropdown">
  <button class="dropbtn">Menu</button>
  <div class="dropdown-content">
    <a href="../login.php">Login</a>
    <a href="../register.php">Register</a>
    <a href="../main.php">Main Menu</a>
    <a href="../item.php">Page items</a>
  </div>
</div>
    
    <?php
    require('../config.php');
    
$id=$_GET['idd'] ;
    
$req = "SELECT * FROM items WHERE id=".$id;
 
// on envoie la requête
$res = $conn->query($req);

$data = mysqli_fetch_array($res);

    
echo ("    
<div align='center'>
<h1 class='title-ia'>".$data['name']."</h1>
<div class='box-table'>

<table>

<colgroup>
    <col span='1' >
    <col span='1' >
</colgroup>


    <th scope='col'><img class='portrait' src='".$data['id'].".png'></th>

</br>
<th scope='col'>


<h1>

Effet: <i>".$data['effect']."</i>
</br>
</br>
</h1>


</th>

</table>
<h1 class='spell-box'>
Champions conseillé par les utilisateurs:
".$data['champions']."
</h1>

</div>
</div>
");
?>

</body>
</html> 
